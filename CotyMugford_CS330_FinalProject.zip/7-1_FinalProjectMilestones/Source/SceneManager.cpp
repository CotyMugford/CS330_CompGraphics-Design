///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/

void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	//Load Platform Texture
	bReturn = CreateGLTexture("textures/Cutting_Board_Texture.jpg", "Platform");

	//Load Whiskey Texture
	bReturn = CreateGLTexture("textures/Whiskey_Color_Texture.jpg", "Whiskey");

	//Load Tile Texture
	bReturn = CreateGLTexture("textures/Tile_Texture.jpg", "Tile");

	//Load Outlet Texture
	bReturn = CreateGLTexture("textures/Wall_Outlet_Texture.jpg", "Outlet");

	//Load Outlet Texture
	bReturn = CreateGLTexture("textures/Wax_Melter_Texture.jpg", "WaxMelter");

	//Load Pepperoni Texture
	bReturn = CreateGLTexture("textures/Pepperoni_Texture.jpg", "Pepperoni");

	//Load Blackberry Texture
	bReturn = CreateGLTexture("textures/Blackberry_Texture.jpg", "Blackberry");

	//Load Apple Texture
	bReturn = CreateGLTexture("textures/Apple_Texture.jpg", "Apple");

	//After the textute image data is loaded into memory, the
	//Loaded textures need to be bound to texture slots - there
	//Are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	//Loads the textures image files for the applied textures
	LoadSceneTextures();
	//Defines the materials being used for the objects
	DefineObjectMaterials();
	//Sets up scene lighting'
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
}

//Object material function
void SceneManager::DefineObjectMaterials()
{

	//Glass Object Material
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 85.0;
	glassMaterial.tag = "Glass";

	m_objectMaterials.push_back(glassMaterial);

	//Wood Object Material
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 2.0;
	woodMaterial.tag = "Wood";

	m_objectMaterials.push_back(woodMaterial);

	//Backdrop object material
	OBJECT_MATERIAL backdropMaterial;
	backdropMaterial.diffuseColor = glm::vec3(0.6f, 0.5f, 0.1f);
	backdropMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	backdropMaterial.shininess = 15.0;
	backdropMaterial.tag = "Backdrop";

	m_objectMaterials.push_back(backdropMaterial);

	//White plastic material
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);
	plasticMaterial.specularColor = glm::vec3(0.70f, 0.70f, 0.70f);
	plasticMaterial.shininess = 32.0;
	plasticMaterial.tag = "Plastic";

	m_objectMaterials.push_back(plasticMaterial);

	//Cheese object material
	OBJECT_MATERIAL cheeseMaterial;
	cheeseMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	cheeseMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	cheeseMaterial.shininess = 3.0;
	cheeseMaterial.tag = "Cheese";

	m_objectMaterials.push_back(cheeseMaterial);

	//Pepperoni object material
	OBJECT_MATERIAL pepperoniMaterial;
	pepperoniMaterial.diffuseColor = glm::vec3(0.5f, 0.3f, 0.3f);
	pepperoniMaterial.specularColor = glm::vec3(0.3f, 0.1f, 0.1f);
	pepperoniMaterial.shininess = 3.0;
	pepperoniMaterial.tag = "Pepperoni";

	m_objectMaterials.push_back(pepperoniMaterial);

	//Blackberry object material
	OBJECT_MATERIAL blackberryMaterial;
	blackberryMaterial.diffuseColor = glm::vec3(0.0f, 0.0f, 0.0f);
	blackberryMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.9f);
	blackberryMaterial.shininess = 20.0;
	blackberryMaterial.tag = "Blackberry";

	m_objectMaterials.push_back(blackberryMaterial);

	//Apple object material
	OBJECT_MATERIAL appleMaterial;
	appleMaterial.diffuseColor = glm::vec3(0.09f, 0.03f, 0.03f);
	appleMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	appleMaterial.shininess = 15.0;
	appleMaterial.tag = "Apple";

	m_objectMaterials.push_back(appleMaterial);

}

//Function that allows for custom lighting for the scene
void SceneManager::SetupSceneLights()
{
	//Allows for custom lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	//Sets the ambient lighting for the scene
	m_pShaderManager->setVec3Value("globalAmbientColor", 0.35, 0.35, 0.35);

	//Light 1 (Wax Melter)
	m_pShaderManager->setVec3Value("lightSources[0].position", 7.0f, 11.0f, 1.5f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.82, 0.49, 0.22);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.82, 0.49, 0.22);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.05f);

	//Light 2 (Ceiling Light)
	m_pShaderManager->setVec3Value("lightSources[1].position", 7.0f, 0.0f, 5.0f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.9, 0.9, 0.9);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.9, 0.9, 0.9);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.02f);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{	
	/******************************************************************/
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	//Renders the cutting board
	RenderPlatform();

	//Renders the backdrop including the outlet
	RenderBackdrop();

	//Renders the wax melter
	RenderWaxMelter();

	//Renders the whiskey glass (allows for movement of the entire glass at once)
	RenderWhiskeyGlass(-4.0f, 1.2f, 2.0f);

	//Renders multiple pieces of pepperoni
	RenderPepperoni(-1.0f, 0.25f, 1.75f, 0.0f, 0.0f, 0.0f);
	float pepperoniX = -1.1f;
	float pepperoniY = 0.4f;
	float pepperoniZ = 2.0f;
	//For loop to render multiple pepperoni
	for (int i = 0; i < 13; i++)
	{
		RenderPepperoni(pepperoniX, pepperoniY, pepperoniZ, 15.0f, 0.0f,  15.0f);
		pepperoniX -= 0.15;
		pepperoniY += .0025;
		pepperoniZ += .2;
		
	}

	RenderPepperoni(-4.0f, 0.25f, 3.8f, 0.0f, 0.0f, 0.0f);
	RenderCheese(-4.0f, 0.6f, 3.8f, 0.0f, 45.0f, 0.0f);

	RenderPepperoni(-1.0f, 0.25f, 3.8f, 0.0f, 0.0f, 0.0f);
	RenderCheese(-1.0f, 0.6f, 3.8f, 0.0f, 45.0f, 0.0f);

	//Nested for loops to render multiple pieces of cheese in multiple layers
	float cheeseX = 0.0;
	float cheeseY = 0.5;
	float cheeseZ = 3.0;
	for (int i = 0; i < 12; i++)
	{
		RenderCheese(cheeseX, cheeseY, cheeseZ, 0.0f, 0.0f, 0.0f);
		cheeseX += .55;
		if (i == 3)
		{
			cheeseX = 0.0;
			cheeseZ = 3.55f;
		}
		else if (i == 7)
		{
			cheeseX = 0.0f;
			cheeseZ = 4.1f;
		}
		else if (i == 11)
		{
			cheeseX = 0.225f;
			cheeseY = 1.0f;
			cheeseZ = 3.85f;
			for (int j = 0; j < 6; j++)
			{
				RenderCheese(cheeseX, cheeseY, cheeseZ, 0.0f, 45.0f, 0.0f);
				cheeseX += 0.55;
				if (j == 2)
				{
					cheeseX = 0.225f;
					cheeseZ = 3.3f;
				}
				else if (j == 5)
				{
					cheeseX = 0.5f;
					cheeseY = 1.5f;
					cheeseZ = 3.55f;
					for (int k = 0; k < 2; k++)
					{
						RenderCheese(cheeseX, cheeseY, cheeseZ, 0.0f, 0.0f, 0.0f);
						cheeseX += 0.55f;
					}

				}
			}
		}
	}

	//Renders the blackberries
	RenderBlackberry(3.25, 0.75, 4.0, 0.0f, 0.0f, 135.0f);
	RenderBlackberry(4.75, 0.75, 4.0, 0.0f, 0.0f, 45.0f);
	RenderBlackberry(4.0, 0.6, 4.0, 90.0f, 0.0f, 135.0f);

	//Renders the apple and stem
	RenderApple();
	
}

//Function to render the platform
void SceneManager::RenderPlatform()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/********************************/
	/******Plane Mesh(Platform)******/
	/********************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(17.5f, 0.5f, 8.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 4.05f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets texture for platform
	SetShaderTexture("Platform");
	//Scales the texture 1x2
	SetTextureUVScale(1.0, 2.0);
	//Sets the platform to wood material
	SetShaderMaterial("Wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
}

//Function to render the backdrop
void SceneManager::RenderBackdrop()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/********************************/
	/*****Plane Mesh(Background)*****/
	/********************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 12.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 5.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets texture for background
	SetShaderTexture("Tile");
	//Scales the texture 2x2
	SetTextureUVScale(1.5, 1.5);
	//Sets the texture to backdrop texture
	SetShaderMaterial("Backdrop");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	/********************************/
	/********** Wall Outlet *********/
	/********************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.5f, 1.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.0f, 5.0f, 0.1f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets texture for background
	SetShaderTexture("Outlet");
	//Scales the texture 1x1
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("Plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/
}

//Function to render the wax melter
void SceneManager::RenderWaxMelter()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/********************************/
	/******* Wax Melter Plug ********/
	/********************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 1.0f, 1.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.0f, 5.5f, 0.77f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets color for background
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	//Sets the material for the plug
	SetShaderMaterial("Plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/********************************/
	/********** Wax Melter **********/
	/********************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 2.5f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.0f, 6.0f, 1.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets texture for background
	SetShaderTexture("WaxMelter");
	SetTextureUVScale(2.0, 2.0);
	SetShaderMaterial("Plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/
}

//Function to render the whiskey glass
void SceneManager::RenderWhiskeyGlass(float x, float y, float z)
{

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************/
	/***Tapered Cylinder(Whiskey Glass Base)***/
	/******************************************/

	//Sets the XYZ scale for the Whiskey Glass Base mesh
	scaleXYZ = glm::vec3(1.5f, 1.0f, 1.5f);

	//Sets the XYZ rotation for the Whiskey Glass Base mesh
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//Sets the XYZ position for the Whiskey Glass Base mesh
	positionXYZ = glm::vec3(x, y, z);

	//Sets the transformations into memory to be used on the drawn Whiskey Glass Base mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the texture for the Whiskey Glass Base
	SetShaderColor(0.7, 0.7, 0.8, 0.7);
	SetShaderMaterial("Glass");

	//Draw the Whiskey Glass Mesh Base with transformation values
	m_basicMeshes->DrawHalfSphereMesh();
	/******************************************/
	/********Cylinder (Whiskey in Glass)*******/
	/******************************************/

	//Sets the XYZ scale for the Whiskey mesh
	scaleXYZ = glm::vec3(1.45f, 0.9f, 1.49f);

	//Sets the XYZ rotation for the Whiskey mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//Sets the XYZ position for the Whiskey mesh
	positionXYZ = glm::vec3(x, y, z);

	//Sets the transformations into memory to be used on the drawn Whiskey mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the texture for the whiskey
	SetShaderTexture("Whiskey");
	SetTextureUVScale(0.5, 0.5);

	//Draw the Whiskey with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/******************************************/
	/*********Cylinder (Whiskey Glass)*********/
	/******************************************/

	//Sets the XYZ scale for the Whiskey Glass mesh
	scaleXYZ = glm::vec3(1.5f, 2.5f, 1.5f);

	//Sets the XYZ rotation for the Whiskey Glass mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//Sets the XYZ position for the Whiskey Glass mesh
	positionXYZ = glm::vec3(x, y, z);

	//Sets the transformations into memory to be used on the drawn Whiskey Glass mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the shader color for the Whiskey Glass 
	SetShaderColor(0.7, 0.7, 0.8, 0.2);
	SetShaderMaterial("Glass");

	//Draw the Whiskey Glass Mesh with transformation values
	m_basicMeshes->DrawCylinderMesh(false, false, true);
}

//Function to render cheese
void SceneManager::RenderCheese(float x, float y, float z, float xRotation, float yRotation, float zRotation)
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************/
	/************** Cheese Cubes **************/
	/******************************************/

	//Sets the XYZ scale for the Cheese mesh
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);

	//Sets the XYZ rotation for the Cheese mesh
	XrotationDegrees = xRotation;
	YrotationDegrees = yRotation;
	ZrotationDegrees = zRotation;

	//Sets the XYZ position for the Cheese mesh
	positionXYZ = glm::vec3(x, y, z);

	//Sets the transformations into memory to be used on the drawn Cheese mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the shader color for the Cheese
	SetShaderColor(0.98, 0.72, 0.17, 1.0);
	SetShaderMaterial("Cheese");
	//Draw the Cheese Mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::RenderPepperoni(float x, float y, float z, float xRotation, float yRotation, float zRotation)
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************/
	/*************** Pepperoni ****************/
	/******************************************/

	//Sets the XYZ scale for the Pepperoni mesh
	scaleXYZ = glm::vec3(0.5f, 0.1f, 0.5f);

	//Sets the XYZ rotation for the Pepperoni mesh
	XrotationDegrees = xRotation;
	YrotationDegrees = yRotation;
	ZrotationDegrees = zRotation;

	//Sets the XYZ position for the Pepperoni mesh
	positionXYZ = glm::vec3(x, y, z);

	//Sets the transformations into memory to be used on the drawn Pepperoni mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the shader color for the Pepperoni
	SetShaderTexture("Pepperoni");
	SetTextureUVScale(4.0, 4.0);
	SetShaderMaterial("Pepperoni");
	//Draw the Pepperoni Mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
}

void SceneManager::RenderBlackberry(float x, float y, float z, float xRotation, float yRotation, float zRotation)
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************/
	/************** Blackberry ****************/
	/******************************************/

	//Sets the XYZ scale for the Apple mesh
	scaleXYZ = glm::vec3(0.4f, 0.6f, 0.4f);

	//Sets the XYZ rotation for the Apple mesh
	XrotationDegrees = xRotation;
	YrotationDegrees = yRotation;
	ZrotationDegrees = zRotation;

	//Sets the XYZ position for the Apple mesh
	positionXYZ = glm::vec3(x, y, z);

	//Sets the transformations into memory to be used on the drawn Apple mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the shader color for the Apple
	SetShaderTexture("Blackberry");
	SetTextureUVScale(4.0, 4.0);
	SetShaderMaterial("Blackberry");
	//Draw the Apple Mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
}

void SceneManager::RenderApple()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************/
	/****************** Stem ******************/
	/******************************************/

	//Sets the XYZ scale for the Stem mesh
	scaleXYZ = glm::vec3(0.9f, 0.1f, 0.1f);

	//Sets the XYZ rotation for the Stem mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 125.0f;

	//Sets the XYZ position for the Stem mesh
	positionXYZ = glm::vec3(4.0f, 2.9f, 2.0f);

	//Sets the transformations into memory to be used on the drawn Stem mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the shader color for the Stem
	SetShaderColor(0.2, 0.1, 0.05, 1.0f);
	SetShaderMaterial("Wood");
	//Draw the Stem Mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/******************************************/
	/***************** Apple ******************/
	/******************************************/

	//Sets the XYZ scale for the Apple mesh
	scaleXYZ = glm::vec3(1.15f, 1.4f, 1.15f);

	//Sets the XYZ rotation for the Apple mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//Sets the XYZ position for the Apple mesh
	positionXYZ = glm::vec3(4.0f, 1.45f, 2.0f);

	//Sets the transformations into memory to be used on the drawn Apple mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Sets the shader color for the Apple
	SetShaderTexture("Apple");
	SetTextureUVScale(4.0, 4.0);
	SetShaderMaterial("Apple");
	//Draw the Apple Mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
}